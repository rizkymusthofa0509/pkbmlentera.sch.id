-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2021 at 05:14 AM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.3.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pkbmlentera`
--

-- --------------------------------------------------------

--
-- Table structure for table `mst_gelombang`
--

CREATE TABLE `mst_gelombang` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` text DEFAULT NULL,
  `date_start` varchar(11) DEFAULT NULL,
  `date_end` varchar(11) DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mst_gelombang`
--

INSERT INTO `mst_gelombang` (`id`, `name`, `date_start`, `date_end`, `is_active`) VALUES
(1, 'Gelombang 1\n', '2021-05-05', '2021-05-06', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mst_paket`
--

CREATE TABLE `mst_paket` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mst_paket`
--

INSERT INTO `mst_paket` (`id`, `name`) VALUES
(1, 'Paket A (SD)'),
(2, 'Paket B (SMP)'),
(3, 'Paket C (SMA)');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_blog`
--

CREATE TABLE `tbl_blog` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_blog`
--

INSERT INTO `tbl_blog` (`id`, `title`, `file`, `is_active`, `description`, `created_by`, `created_at`) VALUES
(1, 'Judul Berita 1', 'default.png', 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n\n', 'Administrator', '2021-05-05 12:12:00'),
(2, 'Judul Berita 2', 'default.png', 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n\n', 'Administrator', '2021-05-05 12:12:00'),
(3, 'Judul Berita 3', 'default.png', 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n\n', 'Administrator', '2021-05-05 12:12:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE `tbl_gallery` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `tipe` enum('video','image') DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_gallery`
--

INSERT INTO `tbl_gallery` (`id`, `title`, `file`, `tipe`, `is_active`, `description`) VALUES
(1, 'Ujian Nasional', 'foto1.png', 'image', 1, NULL),
(2, 'Ujian Nasional', 'video.mp4', 'video', 1, NULL),
(3, 'Ujian Nasional', 'foto1.png', 'image', 1, NULL),
(4, 'Ujian Nasional', 'video.mp4', 'video', 1, NULL),
(5, 'Ujian Nasional', 'foto1.png', 'image', 1, NULL),
(6, 'Ujian Nasional', 'foto1.png', 'image', 1, NULL),
(7, 'Ujian Nasional', 'foto1.png', 'image', 1, NULL),
(8, 'Ujian Nasional', 'foto1.png', 'image', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pembayaran`
--

CREATE TABLE `tbl_pembayaran` (
  `id` int(11) UNSIGNED NOT NULL,
  `siswa_id` int(11) DEFAULT NULL,
  `name` text DEFAULT NULL,
  `nominal` int(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `from_name_bank` varchar(255) DEFAULT NULL,
  `from_number_bank` varchar(255) DEFAULT NULL,
  `to_name_bank` varchar(255) DEFAULT NULL,
  `to_number_bank` varchar(255) DEFAULT NULL,
  `lampiran` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_pembayaran`
--

INSERT INTO `tbl_pembayaran` (`id`, `siswa_id`, `name`, `nominal`, `description`, `from_name_bank`, `from_number_bank`, `to_name_bank`, `to_number_bank`, `lampiran`) VALUES
(1, 1, 'Termin 1', 100000, 'Pembayaran 1', 'BCA', '98120380', 'BCA', '092830123', 'file.pdf'),
(2, 1, 'Termin 2', 120000, 'Pembayaran Tahap 2', 'BCA', '1238912830', 'BCA', '123123123', 'file.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_siswa`
--

CREATE TABLE `tbl_siswa` (
  `id` int(11) UNSIGNED NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` char(50) DEFAULT NULL,
  `username` text DEFAULT NULL,
  `password` text DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `paket_id` int(11) DEFAULT NULL,
  `gelombang_id` int(11) DEFAULT NULL,
  `gender` enum('L','P') DEFAULT NULL,
  `pob` text DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `religion` enum('islam','konghucu','katholik','protestan','hindu','buddha') DEFAULT NULL,
  `kewarganegaraan` text DEFAULT NULL,
  `akta` text DEFAULT NULL,
  `nik` text DEFAULT NULL,
  `nis` text DEFAULT NULL,
  `nisn` text DEFAULT NULL,
  `skhun` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `status_tempat_tinggal` text DEFAULT NULL,
  `is_kip` text DEFAULT NULL,
  `kip_number` text DEFAULT NULL,
  `nomor_telp` text DEFAULT NULL,
  `tinggi_badan` varchar(200) DEFAULT NULL,
  `berat_badan` varchar(200) DEFAULT NULL,
  `ayah_nama` text DEFAULT NULL,
  `ayah_pob` text DEFAULT NULL,
  `ayah_dob` text DEFAULT NULL,
  `ayah_religion` text DEFAULT NULL,
  `ayah_contact` text DEFAULT NULL,
  `ayah_education` text DEFAULT NULL,
  `ayah_work` text DEFAULT NULL,
  `ayah_penghasilan` text DEFAULT NULL,
  `ayah_kebutuhan_khusus` text DEFAULT NULL,
  `ayah_hidup` text DEFAULT NULL,
  `ibu_nama` text DEFAULT NULL,
  `ibu_pob` text DEFAULT NULL,
  `ibu_dob` text DEFAULT NULL,
  `ibu_religion` text DEFAULT NULL,
  `ibu_contact` text DEFAULT NULL,
  `ibu_education` text DEFAULT NULL,
  `ibu_work` text DEFAULT NULL,
  `ibu_penghasilan` text DEFAULT NULL,
  `ibu_kebutuhan_khusus` text DEFAULT NULL,
  `ibu_hidup` varchar(200) DEFAULT NULL,
  `lampiran_kk` text DEFAULT NULL,
  `lampiran_akta` text DEFAULT NULL,
  `lampiran_foto` text DEFAULT NULL,
  `siswa_kebutuhan_khusus` varchar(200) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `updated_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_siswa`
--

INSERT INTO `tbl_siswa` (`id`, `first_name`, `last_name`, `username`, `password`, `email`, `paket_id`, `gelombang_id`, `gender`, `pob`, `dob`, `religion`, `kewarganegaraan`, `akta`, `nik`, `nis`, `nisn`, `skhun`, `address`, `status_tempat_tinggal`, `is_kip`, `kip_number`, `nomor_telp`, `tinggi_badan`, `berat_badan`, `ayah_nama`, `ayah_pob`, `ayah_dob`, `ayah_religion`, `ayah_contact`, `ayah_education`, `ayah_work`, `ayah_penghasilan`, `ayah_kebutuhan_khusus`, `ayah_hidup`, `ibu_nama`, `ibu_pob`, `ibu_dob`, `ibu_religion`, `ibu_contact`, `ibu_education`, `ibu_work`, `ibu_penghasilan`, `ibu_kebutuhan_khusus`, `ibu_hidup`, `lampiran_kk`, `lampiran_akta`, `lampiran_foto`, `siswa_kebutuhan_khusus`, `created_date`, `updated_date`) VALUES
(1, 'Rizky', 'Musthofa', 'admin', 'admin', 'rizkymusthofa0509@gmail.com', 1, 1, 'L', 'Klaten\n', '1999-09-05', 'islam', 'Indonesia', '32120201010100', '32120201010100', '32120201010100', '32120201010100', '32120201010100', 'Jakarta indornsia', 'Ngekos', '1', '321129830123', '0895367330194', NULL, NULL, 'Junawari', 'Indramayu', '1974-06-09', 'islam', '0895367330194', 'SMA', 'Wiraswasta', '1000000', 'Tidak', 'YES', 'Surani', 'Indramayu', '1977-08-08', 'islam', '0895367330194', 'SMP', 'Wiraswasta', '1000000', 'YES', NULL, 'file.pdf', 'file.pdf', 'foto.png', NULL, NULL, NULL),
(9, 'Andika', 'Rachadi', 'Admin', 'admin123', 'tester@gmail.com', 1, 1, 'L', 'Jakarta', '1999-06-06', 'islam', 'Indonesia', '0990090909090', '09090090909090', '9898908988989', '9909000998790', '55555555', 'Depok', 'Sendiri', '0', NULL, NULL, '178', '60', 'admin', 'Jakarta', '1999-06-06', 'islam', '0888768101', 'SMK', '', '200000', '', '1', 'admin', 'Jakarta', '1999-06-06', 'islam', '0888768101', 'SMK', 'Admin', '200000', '', '1', '1d272d733e24ed1b49c2929329ff3989.png', '1ff34687e9f66d8ee2e51839c3bf0b61.png', 'c9b350b4e4a4637b028f86085d6f5dfb.png', NULL, '2021-08-21', '2021-08-21'),
(10, 'Andika', 'Rachadi', 'Admin', 'admin123', 'andika.rach4@gmail.com', 1, 1, 'L', 'Jakarta', '1945-06-06', 'islam', 'Indonesia', '0990090909090', '09090090909090', '9898908988989', '9909000998790', '55555555', 'Depok', 'Sendiri', '0', NULL, NULL, '178', '60', 'admin', 'Jakarta', '1945-06-06', 'islam', '0888768101', 'SMK', 'Admin', '200000', '', '1', 'admin', 'Jakarta', '1999-06-06', 'islam', '0888768101', 'SMK', 'Admin', '200000', '', '1', 'lampiran_kk-10.png', 'lampiran_kk-101.png', 'lampiran_kk-102.png', NULL, '2021-08-21', '2021-08-21'),
(11, 'Andika', 'Rachadi', 'Admin', 'admin123', 'andika.rach4@gmail.com', 1, 1, 'L', 'Jakarta', '1945-06-06', 'islam', 'Indonesia', '0990090909090', '09090090909090', '9898908988989', '9909000998790', '55555555', 'dep', 'Sendiri', '0', NULL, NULL, '178', '60', 'admin', 'Jakarta', '1945-06-06', 'islam', '0888768101', 'SMK', '', '200000', '', '1', 'admin', 'Jakarta', '1945-06-06', 'islam', '0888768101', 'SMK', 'Admin', '200000', '', '1', 'c32383b6d5e4579508d89262bd6eb9fa.png', 'dff8f8f7c8a404cef1c9b72358a6a7d7.png', '1b32583a4a6555cc1205db9268ae1877.png', NULL, '2021-08-21', '2021-08-21'),
(12, 'Andika', 'Rachadi', 'Admin', 'admin123', 'andika.rach4@gmail.com', 1, 1, 'L', 'Jakarta', '1945-06-06', 'islam', 'Indonesia', '0990090909090', '09090090909090', '9898908988989', '9909000998790', '55555555', 'dep', 'Sendiri', '0', NULL, NULL, '178', '60', 'admin', 'Jakarta', '1945-06-06', 'islam', '0888768101', 'SMK', '', '200000', '', '1', 'admin', 'Jakarta', '1945-06-06', 'islam', '0888768101', 'SMK', 'Admin', '200000', '', '1', '3203e2a269129209747b882ef7020217.png', '77cb58b0251d0964c2a07ccf4c2dc67b.png', '8cfea4543faa828c945596499f4116bd.png', NULL, '2021-08-21', '2021-08-21'),
(13, 'Andika', 'Rachadi', 'Admin', 'admin123', 'andika.rach4@gmail.com', 1, 1, 'L', 'Jakarta', '1999-06-06', 'islam', 'Indonesia', '0990090909090', '09090090909090', '9898908988989', '9909000998790', '55555555', 'depok', 'Sendiri', '0', NULL, NULL, '178', '60', 'admin', 'Jakarta', '1945-06-06', 'islam', '0888768101', 'SMK', 'Admin', '200000', '', '1', 'admin', 'Jakarta', '1945-06-06', 'islam', '0888768101', 'SMK', 'Admin', '200000', '', '1', '59509b32175e8eba0d144b6dd4033709.png', 'c1831a416dce6e645463ed7ce80c8fe3.png', '99d225128acd1eb8c2f9d036ad71c599.png', NULL, '2021-08-21', '2021-08-21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_web`
--

CREATE TABLE `tbl_web` (
  `id` int(11) UNSIGNED NOT NULL,
  `school_name` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `visi` text DEFAULT NULL,
  `misi` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT '',
  `contact` varchar(255) DEFAULT '',
  `email` varchar(255) DEFAULT '',
  `facebook` varchar(255) DEFAULT '',
  `instagram` varchar(255) DEFAULT '',
  `linkedin` varchar(255) DEFAULT '',
  `youtube` varchar(255) DEFAULT '',
  `twitter` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_web`
--

INSERT INTO `tbl_web` (`id`, `school_name`, `description`, `visi`, `misi`, `address`, `logo`, `contact`, `email`, `facebook`, `instagram`, `linkedin`, `youtube`, `twitter`) VALUES
(1, 'PKBM LENTERA', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, corporis hic tenetur facere voluptate dolor tempora iste sunt eos quia ab quae labore! Impedit commodi unde, iste distinctio expedita praesentium.', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, corporis hic tenetur facere voluptate dolor tempora iste sunt eos quia ab quae labore! Impedit commodi unde, iste distinctio expedita praesentium.', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, corporis hic tenetur facere voluptate dolor tempora iste sunt eos quia ab quae labore! Impedit commodi unde, iste distinctio expedita praesentium.', 'jalan raya bogor', 'logo.jpg', '0895367330194', 'info@pkbmlentera.sch.id', 'https://facebook.com', 'https://instagram', 'https://facebook.com', 'https://youtube', 'https://facebook.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mst_gelombang`
--
ALTER TABLE `mst_gelombang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mst_paket`
--
ALTER TABLE `mst_paket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pembayaran`
--
ALTER TABLE `tbl_pembayaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_siswa`
--
ALTER TABLE `tbl_siswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_web`
--
ALTER TABLE `tbl_web`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mst_gelombang`
--
ALTER TABLE `mst_gelombang`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mst_paket`
--
ALTER TABLE `mst_paket`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_pembayaran`
--
ALTER TABLE `tbl_pembayaran`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_siswa`
--
ALTER TABLE `tbl_siswa`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_web`
--
ALTER TABLE `tbl_web`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
