<?php
/*
-- ---------------------------------------------------------------
-- JOB CAREER 
-- CREATED BY : RIZKY MUSTHOFA
-- COPYRIGHT  : Copyright (c) 2020 
-- LICENSE    : http://opensource.org/licenses/MIT  MIT License
-- CREATED ON : 2020-06-09
-- UPDATED ON : V.1
-- APP NAME   : JOB CAREER
-- ---------------------------------------------------------------
*/
	// $hostname = 'localhost';
	// $username = 'root';
	// $password = 'mult1f46';
	// $database = 'db_sso';

	$hostname = 'localhost';
	$username = 'root';
	$password = '';
	$database = 'db_pkbmlentera';


	// $hostname = 'localhost';
	// $username = 'poinuid1';
	// $password = 'poi92509';
	// $database = 'poinuid1_bumdes';


 
?>