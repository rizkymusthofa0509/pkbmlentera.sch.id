<h2>PKBM Lentera | Message</h2>
<br>
<p>Pendaftaran berhasil silahkan konfirmasi ke admin</p>