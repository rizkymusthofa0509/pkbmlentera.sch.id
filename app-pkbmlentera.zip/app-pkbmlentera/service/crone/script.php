<?php 

	$hostname = 'localhost';
	$username = 'rizky';
	$password = 'rizky';
	$database = 'db_sso';
 	
 	$conn      = mysqli_connect($hostname,$username,$password,$database);
 	 
?>