		<script>
			$(document).ready(function(){
			  $(".nav-tabs a").click(function(){
			    $(this).tab('show');
			  });
			});
		</script>
	</body>
</html>