<div class="card mt-3">
    <ul class="nav nav-tabs">
        <li class="nav-item">
          <a class="nav-link active" href="#home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#detail">Detail</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#parent">Orang Tua</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#lampiran">Lampiran</a>
        </li>
      </ul>
</div>