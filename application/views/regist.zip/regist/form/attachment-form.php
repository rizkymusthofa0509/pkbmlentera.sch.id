<div id="lampiran" class="tab-pane fade">
	<h3 class="well">Lampiran</h3>
    <div class="form-group">
	    <label class="col-sm-2 control-label text-left">Kartu Keluarga</label>
        <div class="col-sm-10">
            <input type="file" name="file_kk" id="file_kk" class="form-control-file">
        </div>
  </div>
  <div class="form-group">
	    <label class="col-sm-2 control-label text-left">Akta Kelahiran</label>
        <div class="col-sm-10">
            <input type="file" name="file_akta" id="file_akta" class="form-control-file">
        </div>
  </div>
  <div class="form-group">
	    <label class="col-sm-2 control-label text-left">Pas Foto</label>
        <div class="col-sm-10">
            <input type="file" name="file_foto" id="file_foto" class="form-control-file">
        </div>
  </div>
<button type="submit" class="btn btn-primary btn-block">Register</button>
</div>